const ResumeApi = [
  {
    id: 1,
    category: "education",
    year: "University of DVI (1997 - 2001)",
    title: "Personal Portfolio April Fools",
    desc: "The education should be very interactual. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.30/5",
  },
  {
    id: 2,
    category: "education",
    year: "College of Studies (2000 - 2002) ",
    title: "Examples Of Personal Portfolio",
    desc: "Maecenas finibus nec sem ut imperdiet. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.50/5",
  },
  {
    id: 3,
    category: "education",
    year: "University of Studies (1997 - 2001) ",
    title: "Tips For Personal Portfolio",
    desc: "If you are going to use a passage. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.80/5 ",
  },
  {
    id: 4,
    category: "experience",
    year: "BSE In CSE (2004 - 2008) ",
    title: "Diploma in Web Development",
    desc: "Contrary to popular belief. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.70/5 ",
  },
  {
    id: 5,
    category: "experience",
    year: "Job at Rainbow-Themes (2008 - 2016) ",
    title: "The Personal Portfolio Mystery",
    desc: "Generate Lorem Ipsum which looks. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "4.95/5 ",
  },
  {
    id: 6,
    category: "experience",
    year: "Works at Plugin Development (2016 - 2020) ",
    title: "Diploma in Computer Science",
    desc: "Maecenas finibus nec sem ut imperdiet. Ut tincidunt est ac dolor aliquam sodales. Phasellus sed mauris hendrerit, laoreet sem in, lobortis mauris hendrerit ante.",
    rate: "5.00/5 ",
  },
]

export default ResumeApi
