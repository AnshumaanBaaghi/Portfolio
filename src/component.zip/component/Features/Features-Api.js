const data = [
  {
    id: 1,
    image: "https://img.icons8.com/ios/2x/javascript.png",
    title: "Javascript",
    // desc: "I throw myself down among the tall grass by the stream as I lie close to the earth.",
  },
  {
    id: 2,
    image: "https://img.icons8.com/ios/2x/react-native.png",
    title: "React",
    // desc: " It uses a dictionary of over 200 Latin words, combined witha handful of model sentence.",
  },
  {
    id: 3,
    image: "https://img.icons8.com/ios/2x/redux.png",
    title: "Redux",
    // desc: "I throw myself down among the tall grass by the stream as I lie close to the earth.",
  },
  {
    id: 4,
    image: "https://img.icons8.com/external-tal-revivo-bold-tal-revivo/2x/external-mongodb-a-cross-platform-document-oriented-database-program-logo-bold-tal-revivo.png",
    title: "Mongo db",
    // desc: "There are many variations of passages of Lorem Ipsum	available, but the majority.",
  },
  {
    id: 5,
    image: "https://img.icons8.com/windows/2x/nodejs.png",
    title: "Node JS",
    // desc: "always free from repetition, injected humour, or non-characteristic words etc.",
  },
  {
    id: 6,
    image: "https://img.icons8.com/material-outlined/2x/html-5.png",
    title: "Html",
    // desc: " It uses a dictionary of over 200 Latin words, combined with a handful of model sentence.",
  }, {
    id: 7,
    image: "https://img.icons8.com/ios-glyphs/2x/css3.png",
    title: "CSS",
    // desc: " It uses a dictionary of over 200 Latin words, combined with a handful of model sentence.",
  }, {
    id: 8,
    image: "https://img.icons8.com/external-tal-revivo-regular-tal-revivo/2x/external-bootstrap-a-free-and-open-source-css-framework-logo-regular-tal-revivo.png",
    title: "Bootstrap",
    // desc: " It uses a dictionary of over 200 Latin words, combined with a handful of model sentence.",
  },
  {
    id: 9,
    image: "",
    title: "Express JS",
    // desc: " It uses a dictionary of over 200 Latin words, combined with a handful of model sentence.",
  }
]
export default data